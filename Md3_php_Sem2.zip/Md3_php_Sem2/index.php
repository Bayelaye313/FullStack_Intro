<!DOCTYPE html>
<html>
<head>
    <title>Page d'accueil</title>
</head>
<body>
    <h1>Bienvenue sur notre site</h1>
    <p><a href="login.php">Se connecter</a></p>
    <p><a href="inscription.php">Creer un compte</a></p>
</body>
</html>
