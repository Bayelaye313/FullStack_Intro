Projet 2: Créer un landing page responsive avec HTML, CSS et Bootstrap
Dans ce projet on a eu à manipuler les composants bootsrap à savoir:
Accordion
Alerts
Badge
Breadcrumb
Buttons
Button group
Card
Carousel
Close button
Collapse
Dropdowns
List group
Modal
Navs & tabs
Navbar
Offcanvas
en plus des formulaires, les centents(tables, images et typographie)
